<?php return
[
	'success' => 'The operation completed successfully.'
];