<?php return
[
    /*
    |--------------------------------------------------------------------------
    | Email
    |--------------------------------------------------------------------------
    |
    | The language of the Email library.
    |
    */
    
    'email:noSend'                  => 'E-posta gönderilmedi!',
    'email:attachmentMissing'       => 'E-posta eki eksik!',
    'email:attachmentUnreadable'    => 'E-posta eki okunamıyor!',
    'email:noFrom'                  => 'Kimden bilgisi belirtmeden e-posta gönderilemez!',
    'email:noSocket'                => 'E-posta gönderimi için bir yuva açılamıyor! Ayarlarınızı kontrol edin!',
    'email:exitStatus'              => 'Çıkış durum kodu: %',
    'email:mimeMessage'             => 'Bu MIME biçiminde çok parçalı mesajdır.%E-posta uygulaması bu formatı desteklemiyor olabilir.',
    'email:templateColumnError'     => 'Şablon % parametresi kolon bilgisi içermiyor! Kullanım -> table:column',
    'email:templateValueError'      => 'Şablon % parametresi kolon değer bilgisi içermiyor! Kullanım -> whereColumn:value'
];
