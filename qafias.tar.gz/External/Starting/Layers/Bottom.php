<?php
/*
|--------------------------------------------------------------------------
| Bottom
|--------------------------------------------------------------------------
|
| At the lowest layer of the system, the codes that are required to be 
| executed are written.
|
| Location: At the end of the system
|
*/