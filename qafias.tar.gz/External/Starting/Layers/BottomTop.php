<?php
/*
|--------------------------------------------------------------------------
| Bottom Top
|--------------------------------------------------------------------------
|
| The codes that are required to be run on top of the lowest layer of the 
| system are written.
|
| Location: After the kernel run, before the end of the kernel
|
*/
